package com.spring.restapi.fooddelivery.enums;
public enum ResponseStatus
{
    success,
    error
}