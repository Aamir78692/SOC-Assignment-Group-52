package com.spring.restapi.fooddelivery.enums;

public enum Role {
	user, manager, admin
}