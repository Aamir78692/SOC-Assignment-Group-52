package com.spring.restapi.fooddelivery.utils;
public class Helper {
    public static boolean notNull(Object obj){
        return obj != null;
    }
}